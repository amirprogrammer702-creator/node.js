<p align="center">
<a href="https://www.npmjs.com/package/learning-bootstrap4" target="_blank">
<img src="https://badge.fury.io/js/bootstrap.svg" alt="npm version" height="18"></a>
<br>
<a href="https://github.com/omidlmazaheri/learning-bootstrap4" target="_blank">
<img alt="undefined" src="https://img.shields.io/github/license/omidlmazaheri/learning-bootstrap4.svg?style=flat"></a>
</p>
<p align="center">
  <a href="https://getbootstrap.com/">
    <img src="https://getbootstrap.com/docs/4.2/assets/brand/bootstrap-solid.svg" alt="Bootstrap logo" width="72" height="72">
  </a>
</p>

<h3 align="center">Bootstrap</h3>

<p align="center">
  Sleek, intuitive, and powerful front-end framework for faster and easier web development.
  
</p>
<h1>Learning-bootstrap -V4 </h1>  
<h4>bootstrap- v4 Right to Left (RTL)</h4>

## What's included

Within the download you'll find the following directories and files, logically grouping common assets and providing both compiled and minified variations. You'll see something like this:

```text
bootstrap/
├── bootstrap-rtl.css/
├── bootstrap-rtl.min.css/
└── examples/      
```

